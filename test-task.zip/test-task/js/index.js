require('../sass/main.scss');

require('jquery-ui/themes/base/core.css');
require('jquery-ui/themes/base/base.css');
require('jquery-ui/themes/base/theme.css');

require("jquery-ui/ui/widgets/tooltip");
require('jquery-ui/themes/base/tooltip.css');

require("jquery-ui/ui/widgets/dialog");
require('jquery-ui/themes/base/dialog.css');


$( function() {

        $( '[data-toggle="tooltip"]' ).tooltip({
            track: true
        });

    $("#dialog-message").dialog({
        modal: true,
        width: 350,
        resizable: false,
        buttons: {
            Ok: function () {
                $(this).dialog("close");
            }
        }
    });

    $( "#popover-text" ).dialog({
        autoOpen: false,
        position: {
            my: "center bottom",
            at: "center top",
            of: "#popover-open"
        },
        show: {
            effect: "blind",
            duration: 1000
        },
        hide: {
            effect: "explode",
            duration: 1000
        }
    });

    $( "#popover-open" ).on( "click", function() {
        $( "#popover-text" ).dialog( "open" );
    });

} );