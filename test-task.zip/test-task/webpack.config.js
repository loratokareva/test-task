var ExtractTextPlugin = require("extract-text-webpack-plugin");
var path = require('path');
var webpack = require('webpack');

module.exports = {
  entry: './js/index.js',
  output: {
      path: path.resolve(__dirname, 'build'),
      filename: 'bundle.js'
  },
    module: {
        rules: [
            {
                test: /\.scss$/,
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: [{
                        loader: "css-loader"
                    }, {
                        loader: "sass-loader"
                    }]
                })
            },
            {
                test: /\.css$/,
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: "css-loader"
                })
            },
            {
                test: /\.(jpg|png)$/,
                loader: 'file-loader?name=./img/[name][hash].[ext]'
            }

        ]
    },
  plugins: [new webpack.ProvidePlugin({
		  '$': 'jquery',
		  'jQuery': 'jquery'
	}),
      new ExtractTextPlugin("bundle.css")
	]
};

/*
 https://github.com/jzaefferer/webpack-jquery-ui
npm install webpack --save-dev
npm install jquery --save-dev
npm install jquery-ui --save-dev
npm install extract-text-webpack-plugin  --save-dev
npm install style-loader css-loader file-loader --save-dev
npm install sass-loader node-sass --save-dev
*/